# TITU AI Assistant — Android প্রজেক্ট (v2)

এটি **TITU AI Assistant**-এর উন্নত ভার্সন। এতে আছে:

- আধুনিক ডার্ক UI + গ্রেডিয়েন্ট
- **Online Mode** (Google Gemini API)
- Offline Demo Mode (API Key না থাকলে)
- Settings থেকে API Key সেট করা যায় (শুধু ফোনে সেভ হয়)
- Quick prompt বাটন
- Text-to-Speech সাপোর্ট
- Clear chat
- GitHub Actions দিয়ে এক ক্লিকে APK বানানো

---

## গুরুত্বপূর্ণ কথা

- API Key **কখনোই** কোডে বা GitHub-এ রাখবে না।
- Key শুধু তোমার ফোনের localStorage-এ থাকবে।
- Gemini-এর ফ্রি টিয়ার ব্যবহার করতে পারো।

---

## APK বানানোর সবচেয়ে সহজ উপায় (GitHub Actions)

1. এই পুরো ফোল্ডারটি GitHub-এ নতুন Repository তে আপলোড করো।
2. Repository → **Actions** ট্যাবে যাও।
3. `Build TITU AI Assistant APK` workflow সিলেক্ট করো।
4. **Run workflow** চাপো।
5. Build শেষ হলে **Artifacts** থেকে `TITU-AI-Assistant-debug-apk` ডাউনলোড করো।
6. ZIP খুলে `app-debug.apk` ফোনে ইনস্টল করো।

---

## অনলাইন মোড চালু করার নিয়ম

1. অ্যাপ খোলো।
2. উপরের ডানদিকে ⚙️ Settings চাপো।
3. [aistudio.google.com](https://aistudio.google.com) থেকে Gemini API Key নাও।
4. Key পেস্ট করে **Save & Enable Online** চাপো।
5. Status **● ONLINE** হয়ে গেলেই অনলাইন উত্তর পাবে।

---

## Android Studio দিয়ে বিল্ড করতে চাইলে

- প্রজেক্টটি Android Studio-তে ওপেন করো
- Gradle Sync শেষ হোক
- **Build → Build APK(s)** চাপো
- APK পাবে: `app/build/outputs/apk/debug/app-debug.apk`

---

## প্রজেক্ট তথ্য

- Package: `com.titu.aiassistant`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- App Name: TITU AI Assistant

---

তৈরি করেছে: Titu + Grok  
Version: 2.0 (Online Support)
